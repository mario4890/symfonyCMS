<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/includes/_menu.html.twig */
class __TwigTemplate_da6cce3f2a8c98b7aa12004c8fb788a689876a149a0d05e26b8500bc3f287c25 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/includes/_menu.html.twig"));

        // line 1
        echo "<div class=\"d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm\">
    <h5 class=\"my-0 mr-md-auto font-weight-normal\"><a href=\"index.php\">Awesome Videos</a></h5>

    <form method=\"POST\" class=\"form-inline my-0 mr-md-auto\" action=\"";
        // line 4
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("search_result");
        echo "\">
        <input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"video title\" aria-label=\"Search video\">
        <button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search video</button>
    </form>

    <nav class=\"my-2 my-md-0 mr-md-3\">
        <a class=\"p-2 text-dark\" href=\"";
        // line 10
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("video_list");
        echo "\">Funny</a>
        <a class=\"p-2 text-dark\" href=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("video_list");
        echo "\">Scary</a>
        <a class=\"p-2 text-dark\" href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("video_list");
        echo "\">Unbelievable</a>
        <a class=\"p-2 text-dark\" href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("video_list");
        echo "\">Inspirational</a>
        <a class=\"p-2 text-dark\" href=\"";
        // line 14
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("video_list");
        echo "\">Motivating</a>
        <a class=\"p-2 text-dark\" href=\"";
        // line 15
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_main_page");
        echo "\">My account</a>
    </nav>
    <a class=\"btn btn-outline-primary mr-2\" href=\"";
        // line 17
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("pricing");
        echo "\">Sign up</a>
    <a class=\"btn btn-outline-primary\" href=\"";
        // line 18
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\">Sign in</a>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "front/includes/_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 18,  79 => 17,  74 => 15,  70 => 14,  66 => 13,  62 => 12,  58 => 11,  54 => 10,  45 => 4,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm\">
    <h5 class=\"my-0 mr-md-auto font-weight-normal\"><a href=\"index.php\">Awesome Videos</a></h5>

    <form method=\"POST\" class=\"form-inline my-0 mr-md-auto\" action=\"{{ path('search_result') }}\">
        <input class=\"form-control mr-sm-2\" type=\"search\" placeholder=\"video title\" aria-label=\"Search video\">
        <button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search video</button>
    </form>

    <nav class=\"my-2 my-md-0 mr-md-3\">
        <a class=\"p-2 text-dark\" href=\"{{ path('video_list') }}\">Funny</a>
        <a class=\"p-2 text-dark\" href=\"{{ path('video_list') }}\">Scary</a>
        <a class=\"p-2 text-dark\" href=\"{{ path('video_list') }}\">Unbelievable</a>
        <a class=\"p-2 text-dark\" href=\"{{ path('video_list') }}\">Inspirational</a>
        <a class=\"p-2 text-dark\" href=\"{{ path('video_list') }}\">Motivating</a>
        <a class=\"p-2 text-dark\" href=\"{{ path('admin_main_page') }}\">My account</a>
    </nav>
    <a class=\"btn btn-outline-primary mr-2\" href=\"{{ path('pricing') }}\">Sign up</a>
    <a class=\"btn btn-outline-primary\" href=\"{{ path('login') }}\">Sign in</a>
</div>
", "front/includes/_menu.html.twig", "/home/vagrant/vagrant_project/symfony4-my-project/templates/front/includes/_menu.html.twig");
    }
}
