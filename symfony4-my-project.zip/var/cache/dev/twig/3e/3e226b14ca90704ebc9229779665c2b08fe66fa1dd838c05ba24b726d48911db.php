<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/video_details.html.twig */
class __TwigTemplate_c2273bb198ff7ab607bc00eb64def7cba641d09eb34f4c0c8eebd26759a27adf extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/video_details.html.twig"));

        // line 1
        echo "<?php include('includes/_header.php'); ?>
<?php include('includes/_menu.php'); ?>

<br>
<h1>Video title</h1>
<div align=\"center\" class=\"embed-responsive embed-responsive-16by9\">
    <iframe class=\"\" src=\"https://player.vimeo.com/video/289729765\" frameborder=\"0\" allowfullscreen></iframe>
</div>

<hr>

<div class=\"row m-2\">
    <a id=\"video_comments\"></a>

    <?php for (\$i = 1; \$i <= 6; \$i++) : ?>

    <ul class=\"list-unstyled text-left\">
        <li class=\"media\">
            <img class=\"mr-3\" src=\"assets/img/user.jpg\" alt=\"Generic placeholder image\">
            <div class=\"media-body\">
                <h5 class=\"mt-0 mb-1\"><b>John Doe</b> <small class=\"text-muted\">added a comment <small><b>3 days ago</b></small></small></h5>
                Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus
                odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate
                fringilla. Donec lacinia congue felis in faucibus.
            </div>
        </li>
    </ul>
    <hr>

    <?php endfor; ?>

</div>

<div class=\"row\">
    <div class=\"col-md-12\">
        <form method=\"POST\" action=\"video_details.html.twig#video_comments\">
            <div class=\"form-group\">
                <label for=\"exampleFormControlTextarea1\">Add a comment</label>
                <textarea required class=\"form-control\" id=\"exampleFormControlTextarea1\" rows=\"3\"></textarea>
            </div>
            <button type=\"submit\" class=\"btn btn-primary\">Add</button>

        </form>
    </div>
</div>


<?php include('includes/_footer_links.php'); ?>
<?php include('includes/_footer.php'); ?>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "front/video_details.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<?php include('includes/_header.php'); ?>
<?php include('includes/_menu.php'); ?>

<br>
<h1>Video title</h1>
<div align=\"center\" class=\"embed-responsive embed-responsive-16by9\">
    <iframe class=\"\" src=\"https://player.vimeo.com/video/289729765\" frameborder=\"0\" allowfullscreen></iframe>
</div>

<hr>

<div class=\"row m-2\">
    <a id=\"video_comments\"></a>

    <?php for (\$i = 1; \$i <= 6; \$i++) : ?>

    <ul class=\"list-unstyled text-left\">
        <li class=\"media\">
            <img class=\"mr-3\" src=\"assets/img/user.jpg\" alt=\"Generic placeholder image\">
            <div class=\"media-body\">
                <h5 class=\"mt-0 mb-1\"><b>John Doe</b> <small class=\"text-muted\">added a comment <small><b>3 days ago</b></small></small></h5>
                Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus
                odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate
                fringilla. Donec lacinia congue felis in faucibus.
            </div>
        </li>
    </ul>
    <hr>

    <?php endfor; ?>

</div>

<div class=\"row\">
    <div class=\"col-md-12\">
        <form method=\"POST\" action=\"video_details.html.twig#video_comments\">
            <div class=\"form-group\">
                <label for=\"exampleFormControlTextarea1\">Add a comment</label>
                <textarea required class=\"form-control\" id=\"exampleFormControlTextarea1\" rows=\"3\"></textarea>
            </div>
            <button type=\"submit\" class=\"btn btn-primary\">Add</button>

        </form>
    </div>
</div>


<?php include('includes/_footer_links.php'); ?>
<?php include('includes/_footer.php'); ?>
", "front/video_details.html.twig", "G:\\vagrant_project\\symfony4-my-project\\templates\\front\\video_details.html.twig");
    }
}
